<?php

include_once EINAR_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-einarmembership-login-opener-widget.php';
