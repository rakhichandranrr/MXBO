<?php

foreach ( glob( EINAR_MEMBERSHIP_INC_PATH . '/general/dashboard/admin/*.php' ) as $module ) {
	include_once $module;
}

require_once EINAR_MEMBERSHIP_INC_PATH . '/general/class-einarmembership-page-templates.php';
include_once EINAR_MEMBERSHIP_INC_PATH . '/general/helper.php';
