<?php

include_once EINAR_MEMBERSHIP_LOGIN_MODAL_PATH . '/helper.php';

foreach ( glob( EINAR_MEMBERSHIP_LOGIN_MODAL_PATH . '/*/include.php' ) as $module ) {
	include_once $module;
}
