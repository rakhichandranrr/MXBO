<?php

include_once EINAR_CORE_INC_PATH . '/core-dashboard/class-einarcore-dashboard.php';
