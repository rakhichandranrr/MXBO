<?php

include_once EINAR_CORE_INC_PATH . '/opener-icon/helper.php';
