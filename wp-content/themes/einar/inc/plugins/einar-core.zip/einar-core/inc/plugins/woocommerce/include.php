<?php

include_once EINAR_CORE_PLUGINS_PATH . '/woocommerce/class-einarcore-woocommerce.php';
