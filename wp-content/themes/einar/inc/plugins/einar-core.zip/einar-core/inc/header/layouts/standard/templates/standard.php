<?php
// Include logo
einar_core_get_header_logo_image();

// Include main navigation
einar_core_template_part( 'header', 'templates/parts/navigation' );

// Include widget area one
einar_core_get_header_widget_area();
