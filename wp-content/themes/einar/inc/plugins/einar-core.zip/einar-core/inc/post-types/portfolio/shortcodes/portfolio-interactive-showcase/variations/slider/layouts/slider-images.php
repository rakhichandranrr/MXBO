<div class="qodef-e swiper-slide">
	<div class="qodef-e-inner" <?php qode_framework_inline_style( $this_shortcode->get_list_item_style( $params ) ); ?>>
		<?php einar_core_list_sc_template_part( 'post-types/portfolio/shortcodes/portfolio-interactive-showcase', 'post-info/image-background', '', $params ); ?>
	</div>
</div>
