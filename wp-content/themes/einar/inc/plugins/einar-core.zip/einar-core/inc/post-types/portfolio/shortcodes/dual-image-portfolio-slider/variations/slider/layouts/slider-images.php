<div class="qodef-e">
	<div class="qodef-e-inner" <?php qode_framework_inline_style( $this_shortcode->get_list_item_style( $params ) ); ?>>
		<?php einar_core_list_sc_template_part( 'post-types/portfolio/shortcodes/dual-image-portfolio-slider', 'post-info/dual-image', '', $params ); ?>
	</div>
</div>
