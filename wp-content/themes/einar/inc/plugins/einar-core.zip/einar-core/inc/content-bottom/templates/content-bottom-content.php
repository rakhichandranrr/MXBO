<div class="qodef-m-inner <?php echo esc_attr( apply_filters( 'einar_core_filter_content_bottom_inner_classes', 'qodef-content-grid' ) ); ?>">
	<?php dynamic_sidebar( 'qodef-content-bottom' ); ?>
</div>
