<?php

include_once EINAR_CORE_CPT_PATH . '/portfolio/shortcodes/dual-image-portfolio-slider/variations/slider/helper.php';
