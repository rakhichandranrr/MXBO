<?php

include_once EINAR_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-einarcore-dashboard-system-info-page.php';
