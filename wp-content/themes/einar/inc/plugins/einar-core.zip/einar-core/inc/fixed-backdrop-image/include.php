<?php

include_once EINAR_CORE_INC_PATH . '/fixed-backdrop-image/helper.php';
include_once EINAR_CORE_INC_PATH . '/fixed-backdrop-image/dashboard/admin/fixed-backdrop-image-options.php';
include_once EINAR_CORE_INC_PATH . '/fixed-backdrop-image/dashboard/meta-box/fixed-backdrop-image.php';