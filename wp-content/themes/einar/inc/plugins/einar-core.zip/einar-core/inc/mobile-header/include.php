<?php

include_once EINAR_CORE_INC_PATH . '/mobile-header/helper.php';
include_once EINAR_CORE_INC_PATH . '/mobile-header/class-einarcore-mobile-header.php';
include_once EINAR_CORE_INC_PATH . '/mobile-header/class-einarcore-mobile-headers.php';
include_once EINAR_CORE_INC_PATH . '/mobile-header/template-functions.php';
