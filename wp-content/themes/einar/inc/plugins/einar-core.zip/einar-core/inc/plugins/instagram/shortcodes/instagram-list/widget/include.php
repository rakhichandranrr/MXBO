<?php

include_once EINAR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-einarcore-instagram-list-widget.php';
