<?php

include_once EINAR_CORE_INC_PATH . '/header/layouts/simple-tabbed/helper.php';
include_once EINAR_CORE_INC_PATH . '/header/layouts/simple-tabbed/class-einarcore-simple-tabbed-header.php';
include_once EINAR_CORE_INC_PATH . '/header/layouts/simple-tabbed/dashboard/admin/simple-tabbed-header-options.php';
include_once EINAR_CORE_INC_PATH . '/header/layouts/simple-tabbed/dashboard/meta-box/simple-tabbed-header-meta-box.php';
