<?php

include_once EINAR_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-einarcore-twitter-list-widget.php';
