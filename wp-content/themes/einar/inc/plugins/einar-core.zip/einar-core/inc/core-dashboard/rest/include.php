<?php

include_once EINAR_CORE_INC_PATH . '/core-dashboard/rest/class-einarcore-dashboard-rest-api.php';
