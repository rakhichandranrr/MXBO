<?php
if ( ! empty( $fixed_text_one ) ) { ?>
	<div class="qodef-e-fixed-content">
		<h6 class="qodef-fixed-text-one"><?php echo wp_kses_post( $fixed_text_one ); ?></h6>
	</div>
	<?php
}
