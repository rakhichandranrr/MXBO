<?php

include_once EINAR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once EINAR_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-einarcore-instagram-list-shortcode.php';
