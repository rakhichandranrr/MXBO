<?php

include_once EINAR_CORE_CPT_PATH . '/class-einarcore-custom-post-types.php';
