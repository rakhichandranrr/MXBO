<?php
if ( ! empty( $copyright_text ) ) { ?>
	<h6 class="qodef-copyright-text"><?php echo wp_kses_post( $copyright_text ); ?></h6>
	<?php
}
