<?php

include_once EINAR_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-einarcore-twitter-list-shortcode.php';
