<?php

include_once EINAR_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/fade/helper.php';
